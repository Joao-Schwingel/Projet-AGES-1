export type User = {
  userId: number;
  username: string;
  role: string;
};
