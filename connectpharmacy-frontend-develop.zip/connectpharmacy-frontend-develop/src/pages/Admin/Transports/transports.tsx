import { Content } from 'components/Content/context';
import { Layout } from 'components/Layout/layout';

export const AdminTransportsPage: React.FC = () => {
  return (
    <Layout>
      <Content>Tela de lista de transportes para admin (TODO)</Content>
    </Layout>
  );
};
