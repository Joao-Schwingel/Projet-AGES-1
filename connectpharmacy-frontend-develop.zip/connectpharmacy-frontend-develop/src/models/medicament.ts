export interface Medicament {
  medicamentId: number;
  name: string;
  principleActive: string;
  dosage: string;
}
