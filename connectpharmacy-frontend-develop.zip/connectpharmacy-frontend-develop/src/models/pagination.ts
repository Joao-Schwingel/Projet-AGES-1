export interface Pagination<Data> {
  items: Data[];
  totalCount: number;
}
