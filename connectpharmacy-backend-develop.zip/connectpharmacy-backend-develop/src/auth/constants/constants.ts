export const jwtConstants = {
  secret: process.env.JWT_SECRET,
};
