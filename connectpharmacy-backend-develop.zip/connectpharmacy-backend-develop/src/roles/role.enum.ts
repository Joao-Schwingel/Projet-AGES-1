//https://docs.nestjs.com/security/authorization
export enum Role {
  Institution = 'institution',
  Admin = 'admin',
}
