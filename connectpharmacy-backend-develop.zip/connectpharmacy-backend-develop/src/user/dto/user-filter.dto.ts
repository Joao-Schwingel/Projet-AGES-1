export interface UserFilterDto {
  institution_name?: string;
  page?: number;
  pageSize?: number;
}
