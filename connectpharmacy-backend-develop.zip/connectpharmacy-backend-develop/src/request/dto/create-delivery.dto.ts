export class CreateDeliveryDto {
  licensePlate: string;
  description: string;
  status: string;
  driverId: number;
  requestId: number;
}
