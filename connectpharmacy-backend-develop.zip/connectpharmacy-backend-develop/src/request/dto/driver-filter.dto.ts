export interface DriverFilterDto {
    generalRegister?: string;
    page?: number;
    pageSize?: number;
  }
  