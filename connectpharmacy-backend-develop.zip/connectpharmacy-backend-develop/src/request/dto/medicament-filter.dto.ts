export interface MedicamentFilterDto {
  name?: string;
  page?: number;
  pageSize?: number;
}
